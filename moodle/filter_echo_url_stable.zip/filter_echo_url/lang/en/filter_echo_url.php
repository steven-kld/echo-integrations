<?php
$string['filtername'] = 'Echo URL Placeholder';
