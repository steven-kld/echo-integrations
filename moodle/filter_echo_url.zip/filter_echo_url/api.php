<?php
define('AJAX_SCRIPT', true);
define('NO_DEBUG_DISPLAY', true);

require_once(dirname(__DIR__, 2) . '/config.php');

\core\session\manager::init_empty_session();
\core\session\manager::set_user(get_admin());

require_once($CFG->libdir.'/gradelib.php');
require_once($CFG->libdir.'/completionlib.php');
require_once($CFG->dirroot.'/enrol/manual/locallib.php');

header('Content-Type: application/json');

// 🔐 Token check (replace with your actual secret token)
$headers = function_exists('apache_request_headers') ? apache_request_headers() : [];
$authHeader = $headers['Authorization'] ?? ($headers['authorization'] ?? '');

if (strpos($authHeader, 'Bearer ') !== 0 || trim(substr($authHeader, 7)) !== 'yourSuperSecretTokenHere') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

// 📥 Input
$input = json_decode(file_get_contents("php://input"), true);
$userid = intval($input['userid'] ?? 0);
$courseid = (int) ($input['courseid'] ?? 0);
$score = (float) ($input['score'] ?? 100);
$feedback = $input['comment'] ?? 'Completed via Echo interview.';

// 📌 Validate input
if (empty($userid) || empty($courseid)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// 👤 Find user
$user = $DB->get_record('user', ['id' => $userid]);
if (!$user) {
    http_response_code(404);
    echo json_encode(['error' => 'User not found']);
    exit;
}

// 🎓 Find course
$course = $DB->get_record('course', ['id' => $courseid]);
if (!$course) {
    http_response_code(404);
    echo json_encode(['error' => 'Course not found']);
    exit;
}

// 🧮 Build label-based grade item name
$label = 'GRADE: ' . $score;
if (!empty($feedback)) {
    $label .= ' ' . $feedback;
}

// 🧮 Static grade item with editable feedback
try {
    $grade_item = grade_item::fetch([
        'courseid' => $courseid,
        'itemtype' => 'manual',
        'itemname' => 'Echo Review'
    ]);

    if (!$grade_item) {
        $grade_item = new grade_item([
            'courseid' => $courseid,
            'itemtype' => 'manual',
            'itemname' => 'Echo Review',
            'gradetype' => GRADE_TYPE_VALUE,
            'grademax' => 100,
            'grademin' => 0
        ]);
        $grade_item->insert();
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'grade_item_error', 'message' => $e->getMessage()]);
    exit;
}

// 📝 Update grade AND comment
try {
    $grade_item->update_final_grade(
        userid: $user->id,
        finalgrade: $score,
        source: 'plugin',
        feedback: $label,
        feedbackformat: FORMAT_PLAIN,
        usermodified: get_admin()->id
    );    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'grade_update_error',
        'message' => $e->getMessage()
    ]);
    exit;
}

echo json_encode(['status' => 'ok']);
