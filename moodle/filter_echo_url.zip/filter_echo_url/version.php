<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'filter_echo_url';
$plugin->version = 2025060419;
$plugin->requires = 2022041900;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.1';
