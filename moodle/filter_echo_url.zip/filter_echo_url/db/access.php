<?php
// No capabilities yet
